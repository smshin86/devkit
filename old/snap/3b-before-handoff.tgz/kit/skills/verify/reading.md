# 켤 수 없을 때 — 코드로 화면 → 서버 → DB를 따라간다

## 자세
코드가 증명할 때까지 안 된 것으로 본다. 파일이 있다고 되는 것이 아니다(빈 틀도 파일이다). 만든 쪽 보고와 조각 상태는 근거로 쓰지 않는다.

## 장면마다 네 겹
1. **있다** — 필요한 파일·함수가 있다.
2. **속이 찼다** — 빈 틀이 아니라 실제로 하는 일이 들어 있다.
3. **이어졌다** — 다른 쪽이 그것을 불러오고 쓴다.
4. **자료가 흐른다** — 화면에 찍는 값이 진짜 조회에서 온다. 화면의 변수 → 그 값을 넣는 곳 → 조회문까지 거슬러 올라간다.

## 이음매
장면이 지나는 곳마다 양쪽이 맞는지 본다. 한 스택에 묶이지 않는다.

| 이음매 | 무엇을 맞춰 보나 | 예 |
|---|---|---|
| 화면 칸 이름 ↔ 서버가 받는 이름 | 폼의 `name`과 서버가 꺼내는 이름이 같다 | `list.jsp`의 `name="from"` ↔ `BoardController`의 `request.getParameter("from")` / `List.tsx`의 `{ from }` ↔ `posts.py`의 `request.args["from"]` |
| 버튼·폼의 주소 ↔ 받는 서버 코드 | 그 주소와 방식(GET/POST)을 받는 코드가 있다 | `action="/board/save"` ↔ `@PostMapping("/board/save")` / `fetch('/api/posts')` ↔ `@app.get("/api/posts")` |
| 서버 → DB | 조회문이 있고 결과를 돌려준다. 고정값을 돌려주지 않는다 | `BoardController` → `board.xml`의 `selectList` / `posts.py` → `db.execute("select ...")` |
| 서버가 넘긴 이름 ↔ 화면이 꺼내는 이름 | 넘기는 이름과 꺼내는 이름이 같다 | `model.addAttribute("list", …)` ↔ `${list}` / `return {"posts": rows}` ↔ `data.posts` |
| 화면 스크립트가 고르는 id·class ↔ 화면 | 그 id·class가 화면에 실제로 있다 | `$('#dateFrom')` ↔ `list.jsp`의 `id="dateFrom"` / `querySelector('.post-row')` ↔ `List.tsx`의 `className="post-row"` |
| 새 스타일·스크립트 파일 ↔ 화면 | 그 화면이 그 파일을 실제로 불러온다(`screenmap.py lookup`/`used-by`) | `date.js` ↔ `list.jsp`의 `<script src>` / `posts.css` ↔ `App.tsx`의 `import` |
| 끼우는 화면 조각 경로 ↔ 실제 파일 | 적힌 경로에 파일이 있다 | `<jsp:include page="/board/_row.jsp">` ↔ 그 파일 / `import Row from './Row'` ↔ `Row.tsx` |

## 속 빈 곳 찾기
바꾼 파일에서 이런 꼴을 찾는다.
- `TODO`·`FIXME`·"준비 중" 같은 글.
- 빈 것을 돌려주는 줄: `return null`, 빈 목록.
- 화면으로 가는 고정 빈 값: `[]`, `""`을 그대로 넘기는 곳.
- 로그만 찍거나 기본 동작만 막고 아무것도 하지 않는 처리기: `onClick={() => console.log(...)}`, `e.preventDefault()`만 있는 것.
- 조회·요청은 하는데 그 결과를 쓰지 않고 고정 답(`{ok: true}`)을 돌려주거나, 값을 받아 두고 화면은 늘 "없음"을 찍는 곳.
걸린 것이 다른 길에서 진짜 값으로 채워지면 속 빈 것이 아니다. 그 길까지 따라가 본 뒤에 판정한다.

## 판정
- 끊긴 곳이나 속 빈 곳을 찾았다 → `안 됨`. 없는 것을 봤는데 `확인 못 함`이라고 하지 않는다.
- 끝까지 이어졌고 끊긴 곳이 없다 → `읽어서는 이어짐`. 이것을 `됨`이라고 쓰지 않는다. 켜서 본 것이 아니다.
- 코드 밖(바깥 서비스, 폴더 밖 설정)이라 따라갈 수 없다 → `확인 못 함`. 어디서 막혔는지 본 것 칸에 적는다.
- 본 것 칸에는 따라간 길을 짧게 적는다: `list.html:42 → ExcelController.down → board.xml selectList`.

## 사람에게 남길 것
눈으로만 알 수 있는 것(모양, 흐름이 자연스러운지)은 `못 본 것:` 줄에 적는다.
