import importlib.util
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCRIPT = ROOT / "kit" / "skills" / "screen-map" / "screenmap.py"
spec = importlib.util.spec_from_file_location("screenmap", SCRIPT); sm = importlib.util.module_from_spec(spec); spec.loader.exec_module(sm)
FIX = ROOT / "tests" / "fixtures" / "site"
J = "web/WEB-INF/jsp/"          # 지도 안 경로의 앞부분


# ---- 과제 1: 파일 한 개를 읽어 낸다 ----

def scan(rel): return sm.scan_markup(sm.read_text(FIX / J / rel))

def test_scan_layout_with_own_head():
    m = scan("la/a/subLayout.jsp")
    assert m["head"] is True
    assert m["loads"] == ["/css/common.css", "/css/board.css", "/js/a/jquery.min.js", "/js/confirm.js", "/css/web/${ctx}/layout.css"]
    assert m["includes"] == [{"target": "header.jsp", "dynamic": False}, {"target": "/WEB-INF/jsp/${content}", "dynamic": True}]

def test_scan_head_file_multiline_tag_and_c_url():
    m = scan("la/common/meta.jsp")
    assert m["head"] is True
    assert m["loads"] == ["/css/common.css", "/js/b/jquery.min.js", "/js/form.js"]

def test_scan_fragment_keeps_unfollowable_includes_but_not_external():
    m = scan("bk/list.jsp")
    assert m == {"head": False, "loads": [], "includes": [
        {"target": "part.jsp", "dynamic": False}, {"target": "/common/fileUpload.do", "dynamic": False}]}

def test_read_text_survives_non_utf8():
    assert scan("bk/euckr.jsp")["loads"] == ["/js/part.js"]


# ---- 과제 2: 프로젝트 전체를 훑어 지도를 만든다 ----

def test_build_shape_and_skip():
    m = sm.build(FIX)
    assert set(m) == {"version", "built_at", "pages"}
    assert J + "bk/list.jsp" in m["pages"] and not any("node_modules" in p for p in m["pages"])
    incs = m["pages"][J + "bk/list.jsp"]["includes"]
    assert [i["file"] for i in incs] == [J + "bk/part.jsp", None]

def test_closure_loads_head_follow_includes_and_survive_cycles():
    m = sm.build(FIX)
    assert sm.loads_of(m, J + "bk/list.jsp") == ["/js/part.js"]
    assert sm.loads_of(m, J + "la/a/subLayout.jsp")[-1] == "/js/menu.js"      # header.jsp ↔ subLayout.jsp 순환
    b = J + "la/b/subLayout.jsp"
    assert m["pages"][b]["head"] is False and sm.has_head(m, b) is True
    assert sm.loads_of(m, b) == ["/css/web/${ctx}/layout.css", "/css/common.css", "/js/b/jquery.min.js", "/js/form.js"]

def test_is_wrapper():
    m = sm.build(FIX)
    # header.jsp는 subLayout.jsp를 그대로 끼워 넣으므로(순환) 그것도 틀이다
    assert [p[len(J):] for p in sorted(m["pages"]) if sm.is_wrapper(m, p)] == [
        "la/a/header.jsp", "la/a/subLayout.jsp", "la/b/subLayout.jsp", "la/c/mainLayout.jsp"]

def test_cli_build_writes_map(tmp_path):
    out = tmp_path / "map.json"
    r = subprocess.run([sys.executable, str(SCRIPT), "build", str(FIX), "--out", str(out)], capture_output=True, text=True)
    assert r.returncode == 0 and json.loads(out.read_text(encoding="utf-8"))["version"] == 1
    assert "화면 파일 9개를 적었습니다 (다른 화면을 끼워 넣는 틀 4개)" in r.stdout


# ---- 과제 3: 화면 하나를 찾아본다 ----

EXPECTED_LIST_LOOKUP = """화면: web/WEB-INF/jsp/bk/list.jsp
종류: 조각 — 스스로 <head>가 없다. 실행 중에 틀 안에 끼워져서 보인다.
이 화면이 불러오는 파일 (그대로 끼워 넣은 조각 것 포함):
  /js/part.js
따라가지 못한 끼워 넣기 (이 안에서 무엇을 불러오는지는 지도에 없다):
  /common/fileUpload.do
이 화면을 그대로 끼워 넣는 파일: 없음
다른 화면을 실행 중에 끼워 넣는 틀: 3묶음
  [web/WEB-INF/jsp/la/*/subLayout.jsp] 2개 — 끼워 넣는 대상: /WEB-INF/jsp/${content}
    2/2  /css/common.css
    2/2  jquery.min.js (경로 2가지)
    2/2  /css/web/${ctx}/layout.css
    1/2  /css/board.css
    1/2  /js/confirm.js
    1/2  /js/form.js
    1/2  /js/menu.js
  [web/WEB-INF/jsp/la/*/header.jsp] 1개 — 끼워 넣는 대상: /WEB-INF/jsp/${content}
    1/1  /css/board.css
    1/1  /css/common.css
    1/1  /js/confirm.js
    1/1  /js/a/jquery.min.js
    1/1  /css/web/${ctx}/layout.css
    1/1  /js/menu.js
  [web/WEB-INF/jsp/la/*/mainLayout.jsp] 1개 — 끼워 넣는 대상: /WEB-INF/jsp/la/${ctx}/main.jsp
    1/1  /css/main.css
읽는 법: "1/2"는 그 묶음의 틀 2개 중 1개가 불러온다는 뜻이다. 경로가 달라도 파일 이름이 같으면 한 줄로 합쳤다.
어느 묶음이 이 화면을 감싸는지는 지도에 없다. 이 화면을 돌려주는 서버 코드에서 틀 이름을 확인한다.
틀 전부가 불러오지는 않는 파일에 기대게 되면, 같은 모양의 이웃 화면이 어떻게 하는지 따르고 그 사실을 보고에 적는다.
조건이 붙은 불러오기(특정 경우에만)와 스크립트가 실행 중에 불러오는 것은 구분하지 못한다."""

def test_lookup_fragment_exact_text():
    out = sm.lookup(sm.build(FIX), J + "bk/list.jsp")
    assert out.splitlines()[:-1] == EXPECTED_LIST_LOOKUP.splitlines()
    assert out.splitlines()[-1].startswith("지도를 만든 때: ")

def test_lookup_wrapper_has_no_group_section():
    out = sm.lookup(sm.build(FIX), J + "la/a/subLayout.jsp")
    assert "종류: 틀 — " in out and "묶음" not in out and "/js/menu.js" in out

def test_lookup_head_file_kind_and_includers():
    out = sm.lookup(sm.build(FIX), J + "la/common/meta.jsp")
    assert "종류: 스스로 <head>가 있는 파일" in out and "  " + J + "la/b/subLayout.jsp" in out and "3묶음" in out

def test_lookup_file_filter():
    m = sm.build(FIX)
    out = sm.lookup(m, J + "bk/list.jsp", file_filter="JQUERY")
    assert "    1/2  /js/a/jquery.min.js" in out and "    1/2  /js/b/jquery.min.js" in out
    assert "    0/1  JQUERY — 불러오는 틀 없음" in out          # mainLayout 묶음
    assert "    0/2  fileDownload — 불러오는 틀 없음" in sm.lookup(m, J + "bk/list.jsp", file_filter="fileDownload")

def test_find_page_forms():
    m = sm.build(FIX)
    assert sm.find_page(m, "bk/list.jsp") == [J + "bk/list.jsp"]
    assert sm.find_page(m, str(FIX / J / "bk/list.jsp"), FIX) == [J + "bk/list.jsp"]
    assert sm.find_page(m, "subLayout.jsp") == [J + "la/a/subLayout.jsp", J + "la/b/subLayout.jsp"]
    assert sm.find_page(m, "ist.jsp") == []          # 칸 경계에서만 맞춘다

def test_cli_lookup_and_errors(tmp_path):
    run = lambda *a: subprocess.run([sys.executable, str(SCRIPT), *a], capture_output=True, text=True)
    mp = str(tmp_path / "m.json")
    r = run("lookup", str(FIX), "bk/list.jsp", "--map", mp)
    assert r.returncode == 1 and "지도가 없습니다" in r.stdout
    run("build", str(FIX), "--out", mp)
    assert run("lookup", str(FIX), "bk/list.jsp", "--map", mp).returncode == 0
    assert run("lookup", str(FIX), "nope.jsp", "--map", mp).returncode == 1
    r = run("lookup", str(FIX), "subLayout.jsp", "--map", mp)
    assert r.returncode == 1 and "여러 개가 걸립니다" in r.stdout


# ---- 검토에서 나온 구멍: 소리 없이 빠뜨리던 꼴들 ----

def test_scan_tags_with_gt_inside_attribute_values():
    text = """<script src="<%=request.getContextPath()%>/js/a.js"></script>
<script src="/js/b.js?v=<%=ver%>"></script>
<link href="<c:out value='${ctx}'/>/css/c.css">
<script src="<spring:url value="/js/d.js"/>"></script>
<c:url value='/a.do' var="u"/>
<script src='/js/z.js'></script>
<script src=/js/f.js></script>
<SCRIPT SRC=" /JS/G.JS "></SCRIPT>"""
    assert sm.scan_markup(text)["loads"] == [
        "${request.getContextPath()}/js/a.js", "/js/b.js", "${ctx}/css/c.css", "/js/d.js", "/js/z.js", "/js/f.js", "/JS/G.JS"]

def test_scan_includes_in_any_attribute_order():
    text = """<jsp:include flush="true" page="x.jsp"/>
<c:import var="v" url="/WEB-INF/${content}"/>
<jsp:directive.include file="z.jsp"/>
<jsp:include page="<%=path%>"/>"""
    assert sm.scan_markup(text)["includes"] == [
        {"target": "x.jsp", "dynamic": False}, {"target": "/WEB-INF/${content}", "dynamic": True},
        {"target": "z.jsp", "dynamic": False}, {"target": "${path}", "dynamic": True}]

def _site(tmp_path, files):
    for rel, text in files.items():
        (tmp_path / rel).parent.mkdir(parents=True, exist_ok=True)
        (tmp_path / rel).write_text(text, encoding="utf-8")
    return sm.build(tmp_path)

def test_wrapper_whose_slot_lives_in_a_static_fragment(tmp_path):
    m = _site(tmp_path, {
        "la/x/layout.jsp": '<head></head><%@ include file="body.jsp" %>',
        "la/x/body.jsp": '<c:import url="/WEB-INF/${content}"/>'})
    assert sm.is_wrapper(m, "la/x/layout.jsp") and not sm.is_wrapper(m, "la/x/body.jsp")
    assert sm.wrapper_groups(m)[0]["slots"] == ["/WEB-INF/${content}"]

def test_two_part_paths_group_together(tmp_path):
    page = '<head></head><jsp:include page="${c}"/>'
    m = _site(tmp_path, {"a/layout.jsp": page, "b/layout.jsp": page, "top.jsp": page})
    assert [(g["pattern"], len(g["files"])) for g in sm.wrapper_groups(m)] == [("*/layout.jsp", 2), ("top.jsp", 1)]

def test_cli_refuses_missing_project_and_broken_map(tmp_path):
    run = lambda *a: subprocess.run([sys.executable, str(SCRIPT), *a], capture_output=True, text=True)
    r = run("build", str(tmp_path / "nope"))
    assert r.returncode == 1 and "프로젝트 폴더가 없습니다" in r.stdout and not (tmp_path / "nope").exists()
    bad = tmp_path / "bad.json"; bad.write_text("{", encoding="utf-8")
    r = run("lookup", str(FIX), "bk/list.jsp", "--map", str(bad))
    assert r.returncode == 1 and "지도 파일을 읽지 못했습니다" in r.stdout
